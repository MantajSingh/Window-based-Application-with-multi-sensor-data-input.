﻿
namespace Sereal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BtnScanPort = new System.Windows.Forms.Button();
            this.CmbScanPort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbBaud = new System.Windows.Forms.ComboBox();
            this.BtnCon = new System.Windows.Forms.Button();
            this.BtnDiscon = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.angularGauge1 = new LiveCharts.Wpf.AngularGauge();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnScanPort
            // 
            this.BtnScanPort.BackColor = System.Drawing.SystemColors.Info;
            this.BtnScanPort.Location = new System.Drawing.Point(31, 66);
            this.BtnScanPort.Name = "BtnScanPort";
            this.BtnScanPort.Size = new System.Drawing.Size(71, 23);
            this.BtnScanPort.TabIndex = 0;
            this.BtnScanPort.Text = "Scan Port";
            this.BtnScanPort.UseVisualStyleBackColor = false;
            this.BtnScanPort.Click += new System.EventHandler(this.BtnScanPort_Click);
            // 
            // CmbScanPort
            // 
            this.CmbScanPort.FormattingEnabled = true;
            this.CmbScanPort.Location = new System.Drawing.Point(108, 68);
            this.CmbScanPort.Name = "CmbScanPort";
            this.CmbScanPort.Size = new System.Drawing.Size(121, 21);
            this.CmbScanPort.TabIndex = 1;
            this.CmbScanPort.SelectedIndexChanged += new System.EventHandler(this.CmbScanPort_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(235, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Baut Rate :";
            // 
            // CmbBaud
            // 
            this.CmbBaud.FormattingEnabled = true;
            this.CmbBaud.Items.AddRange(new object[] {
            "9600",
            "115200"});
            this.CmbBaud.Location = new System.Drawing.Point(302, 68);
            this.CmbBaud.Name = "CmbBaud";
            this.CmbBaud.Size = new System.Drawing.Size(121, 21);
            this.CmbBaud.TabIndex = 3;
            this.CmbBaud.SelectedIndexChanged += new System.EventHandler(this.CmbBaud_SelectedIndexChanged);
            // 
            // BtnCon
            // 
            this.BtnCon.BackColor = System.Drawing.Color.Green;
            this.BtnCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCon.Location = new System.Drawing.Point(442, 49);
            this.BtnCon.Name = "BtnCon";
            this.BtnCon.Size = new System.Drawing.Size(128, 80);
            this.BtnCon.TabIndex = 4;
            this.BtnCon.Text = "Connect";
            this.BtnCon.UseVisualStyleBackColor = false;
            this.BtnCon.Click += new System.EventHandler(this.BtnCon_Click);
            // 
            // BtnDiscon
            // 
            this.BtnDiscon.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDiscon.Location = new System.Drawing.Point(31, 149);
            this.BtnDiscon.Name = "BtnDiscon";
            this.BtnDiscon.Size = new System.Drawing.Size(75, 37);
            this.BtnDiscon.TabIndex = 5;
            this.BtnDiscon.Text = "Send";
            this.BtnDiscon.UseVisualStyleBackColor = true;
            this.BtnDiscon.Click += new System.EventHandler(this.BtnDiscon_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(31, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(392, 20);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "Type Control Command Then Press Send";
            this.textBox1.TextChanged += new System.EventHandler(this.textShow);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.DarkSalmon;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(31, 272);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(198, 38);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox3.Location = new System.Drawing.Point(31, 371);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(198, 38);
            this.textBox3.TabIndex = 8;
            // 
            // elementHost1
            // 
            this.elementHost1.BackColor = System.Drawing.SystemColors.Highlight;
            this.elementHost1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elementHost1.BackgroundImage")));
            this.elementHost1.Location = new System.Drawing.Point(269, 135);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(301, 303);
            this.elementHost1.TabIndex = 9;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.elementHost1_ChildChanged);
            this.elementHost1.Child = this.angularGauge1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 252);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Temprature";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 351);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Co2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(172, 9);
            this.label4.MinimumSize = new System.Drawing.Size(60, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(267, 32);
            this.label4.TabIndex = 12;
            this.label4.Text = "RDS Industrial Panel";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(582, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.elementHost1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.BtnCon);
            this.Controls.Add(this.CmbBaud);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CmbScanPort);
            this.Controls.Add(this.BtnScanPort);
            this.Controls.Add(this.BtnDiscon);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Multiple Ports";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnScanPort;
        private System.Windows.Forms.ComboBox CmbScanPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbBaud;
        private System.Windows.Forms.Button BtnCon;
        private System.Windows.Forms.Button BtnDiscon;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private LiveCharts.Wpf.AngularGauge angularGauge1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

