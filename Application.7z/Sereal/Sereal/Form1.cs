﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Windows;

using System.Windows.Media;
using LiveCharts.Wpf;
using Brushes = System.Windows.Media.Brushes;

namespace Sereal
{
    

    public partial class Form1 : Form
    {
        String DataIn;
        String DataOut;
        public static Double Result;
        public static Double Result2;
        public static String ForText1;
        public static String ForText2;
        Decimal Value2;
       int updateData;
        int val;

        

        

        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Me.CenterToParent();
            //BtnCon.Enabled = false;
            //BtnCon.BringToFront();
            //BtnDiscon.Enabled = false;
            //BtnDiscon.SendToBack();
            string[] portLists = SerialPort.GetPortNames();
            CmbScanPort.Items.AddRange(portLists);
        }

        private void BtnScanPort_Click(object sender, EventArgs e)
        {

           // CmbScanPort.Items.Clear();
            //Dim myPort as Array;

        }

        private void CmbScanPort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CmbBaud_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnCon_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = CmbScanPort.Text;
            serialPort1.BaudRate = Convert.ToInt32(CmbBaud.Text);
            serialPort1.Open();
        }

        private void BtnDiscon_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
            {
                DataOut = textBox1.Text;
                serialPort1.WriteLine(DataOut);
  
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            DataIn = serialPort1.ReadTo("\n");
            this.Invoke(new EventHandler(showData));
            Data_Parsing(DataIn);
           // textBox2.Text = DataIn;

          //  this.Invoke(new Evethandler(ShowData));
        }

        private void showData(object sender, EventArgs e)
        {
            // throw new NotImplementedException();

            if(updateData == 1)
            {
                textBox2.Text = ForText1;
                textBox3.Text = ForText2;

                angularGauge1.Value = Result;
               // textBox3.Text = Result2;
            }


           // textBox2.Text += DataIn;
            
            //something
        }

        private void Data_Parsing(string data)
        {
            sbyte indexOf_startDataCharacter = (sbyte)data.IndexOf("@");
            sbyte indexOfA = (sbyte)data.IndexOf("A");
            sbyte indexOfB = (sbyte)data.IndexOf("B");

            if (indexOfA!=-1 && indexOfB!=-1 && indexOf_startDataCharacter!=-1)
            {

                try
                {
                    string str_philaTota = data.Substring(indexOf_startDataCharacter + 1, (indexOfA -
                        indexOf_startDataCharacter) - 1);
                    string str_dujaTota = data.Substring(indexOfA + 1, (indexOfB - indexOfA) - 1);

                    Result = Convert.ToDouble(str_philaTota);
                    Result2 = Convert.ToDouble(str_dujaTota);
                    ForText1 = str_philaTota;
                    ForText2 = str_dujaTota;

                    // textBox2.Text = Result;

                    updateData = 1;

                }

                catch(Exception)
                {

                }
            }
            else
            {
                updateData = 0;
            }
        }
  

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           // textBox1.Text = DataIn;
        }

        private void textShow(object sender, EventArgs e)
        {
            
        }

        private void elementHost1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

            {

               // val = Convert.ToInt32(Form1.Result);
                //angularGauge1.Value =val;
                angularGauge1.FromValue = 0;
                angularGauge1.ToValue = 1000;
                angularGauge1.TicksForeground = Brushes.White;
                angularGauge1.Foreground = Brushes.White;
                angularGauge1.FontWeight = FontWeights.Bold;
                angularGauge1.FontSize = 16;
                angularGauge1.SectionsInnerRadius = 0.5;

               

            }


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
